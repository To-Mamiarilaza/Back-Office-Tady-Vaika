
export default function AnnonceDetail() {
    
}