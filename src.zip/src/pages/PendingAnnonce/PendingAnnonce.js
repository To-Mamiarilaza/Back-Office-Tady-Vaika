
export default function PendingAnnonce() {
        
}