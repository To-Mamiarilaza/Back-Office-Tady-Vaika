import "./App.css";
import "./template.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "./assets/fonts/fontawesome-free-6.5.1-web/css/all.css";

import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import LoginPage from "./pages/LoginPage/LoginPage";
import Header from "./components/Header/Header";
import Dashboard from "./pages/Dashboard/Dashboard";
import PendingAnnonce from "./pages/PendingAnnonce/PendingAnnonce";
import AnnonceDetail from "./pages/AnnonceDetail/AnnonceDetail";
import UserProfile from "./pages/UserProfile/UserProfile";
import UserAnnonces from "./pages/UserAnnonces/UserAnnonces";
import ElementsCrud from "./pages/ElementsCrud/ElementsCrud";
import AnnonceCrud from "./pages/AnnonceCrud/AnnonceCrud";

export default function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/login" exact Component={LoginPage} />
          <Route
            path="/*"
            exact
            element={
              <>
                <div className="sidebar">
                  <a className="sidebar-link sidebar-link-red" href="">
                    <i className="fas fa-search"></i>
                  </a>
                  <a className="sidebar-link" href="">
                    <i className="fas fa-chart-line"></i>
                    <div className="link-name">DASHBOARD</div>
                  </a>
                  <a className="sidebar-link" href="">
                    <i className="fas fa-cog"></i>
                    <div className="link-name">PARAMETRE</div>
                  </a>
                </div>

                <div className="content">
                  <Header/>
                  <Routes>
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route
                      path="/annonces/pending"
                      element={<PendingAnnonce />}
                    />
                    <Route path="/annonces/:id" element={<AnnonceDetail />} />
                    <Route path="/user/:id/profile" element={<UserProfile />} />
                    <Route
                      path="/user/:id/annonces"
                      element={<UserAnnonces />}
                    />
                    <Route path="/elements/crud" element={<ElementsCrud />} />
                    <Route path="/annonce/crud" element={<AnnonceCrud />} />
                  </Routes>
                </div>
              </>
            }
          />
        </Routes>
      </Router>
    </>
  );
}
